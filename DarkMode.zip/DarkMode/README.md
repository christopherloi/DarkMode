# DarkMode
 Google Chrome extension that makes Google Chrome have dark mode like your desktop or phone.
